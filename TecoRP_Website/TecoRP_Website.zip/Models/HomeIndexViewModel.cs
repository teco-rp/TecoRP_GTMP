﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TecoRP_Website.Models
{
    public class HomeIndexViewModel
    {
        public string OwnerSocialClubName { get; set; }
        public bool ConfigurationEnabled { get; set; }
    }
}